﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using StudentSystem.Models;

namespace StudentSystem.Controllers
{
    public class HomeController : Controller
    {
        public ViewResult Index()
        {
            Student student = new Student
            {
                FirstName = "Aderson",
                LastName = "Oliveira"
            };

            return View(student);
        }

        public ViewResult ListStudents()
        {
            List<Student> students = new List<Student>
            {
                new Student {
                    FirstName = "Aderson",
                    LastName = "Oliveira",
                    CourseCode = "COMP229",
                    Email = "aderson@google.com",
                    FullTime = false,
                    Gpa = 1.9,
                    StudentId = 300001
                },
                new Student {
                    FirstName = "John",
                    LastName = "Smith",
                    CourseCode = "COMP123",
                    Email = "john@smith.com",
                    FullTime = true,
                    Gpa = 3.9,
                    StudentId = 300002
                },
                new Student {
                    FirstName = "Mary",
                    LastName = "Jane",
                    CourseCode = "COMP100",
                    Email = "mary@jane.com",
                    FullTime = false,
                    Gpa = 2.5,
                    StudentId = 300003
                },
                new Student {
                    FirstName = "Rose",
                    LastName = "Linda",
                    CourseCode = "COMP321",
                    Email = "rose@linda.com",
                    FullTime = true,
                    Gpa = 3.5,
                    StudentId = 300004
                }
            };
            return View(students);
        }
    }
}
